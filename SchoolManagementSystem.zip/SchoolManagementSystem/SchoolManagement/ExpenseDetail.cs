﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace SchoolManagement
{
    public partial class ExpenseDetail : Form
    {
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationSettings.AppSettings["School"].ToString());
        public ExpenseDetail()
        {
            InitializeComponent();
        }

        private void ExpenseDetail_Load(object sender, EventArgs e)
        {
            SqlDataAdapter adptr = new SqlDataAdapter("select * from Vw_Expense", con);
            DataSet ds = new DataSet();
            adptr.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                dataGridView1.DataSource = ds.Tables[0];
            }
        }
    }
}
