﻿namespace SchoolManagement
{
    partial class NewExpense
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.expensedate = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.amount = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.name = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.expenseid = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.expensetype = new System.Windows.Forms.ComboBox();
            this.tblexpensetypeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolmanagementDataSet1 = new SchoolManagement.schoolmanagementDataSet1();
            this.tblexpensetypeTableAdapter = new SchoolManagement.schoolmanagementDataSet1TableAdapters.tblexpensetypeTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.tblexpensetypeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolmanagementDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // expensedate
            // 
            this.expensedate.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expensedate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.expensedate.Location = new System.Drawing.Point(127, 153);
            this.expensedate.Name = "expensedate";
            this.expensedate.Size = new System.Drawing.Size(117, 23);
            this.expensedate.TabIndex = 76;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(23, 153);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 16);
            this.label9.TabIndex = 75;
            this.label9.Text = "Expense Date";
            // 
            // amount
            // 
            this.amount.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amount.Location = new System.Drawing.Point(127, 124);
            this.amount.Name = "amount";
            this.amount.Size = new System.Drawing.Size(117, 23);
            this.amount.TabIndex = 74;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(63, 127);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 16);
            this.label10.TabIndex = 73;
            this.label10.Text = "Amount";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(241, 199);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 72;
            this.button1.Text = "Cancel";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(22, 97);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(99, 16);
            this.label7.TabIndex = 71;
            this.label7.Text = "Expense Type";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(145, 199);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 70;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // name
            // 
            this.name.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.Location = new System.Drawing.Point(127, 65);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(217, 23);
            this.name.TabIndex = 69;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(77, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 16);
            this.label4.TabIndex = 68;
            this.label4.Text = "Name";
            // 
            // expenseid
            // 
            this.expenseid.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expenseid.Location = new System.Drawing.Point(127, 36);
            this.expenseid.Name = "expenseid";
            this.expenseid.Size = new System.Drawing.Size(64, 23);
            this.expenseid.TabIndex = 67;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(48, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 16);
            this.label3.TabIndex = 66;
            this.label3.Text = "Expenseid";
            // 
            // expensetype
            // 
            this.expensetype.DataSource = this.tblexpensetypeBindingSource;
            this.expensetype.DisplayMember = "expensetype";
            this.expensetype.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expensetype.FormattingEnabled = true;
            this.expensetype.Location = new System.Drawing.Point(127, 94);
            this.expensetype.Name = "expensetype";
            this.expensetype.Size = new System.Drawing.Size(117, 24);
            this.expensetype.TabIndex = 77;
            this.expensetype.ValueMember = "expensetypeid";
            // 
            // tblexpensetypeBindingSource
            // 
            this.tblexpensetypeBindingSource.DataMember = "tblexpensetype";
            this.tblexpensetypeBindingSource.DataSource = this.schoolmanagementDataSet1;
            // 
            // schoolmanagementDataSet1
            // 
            this.schoolmanagementDataSet1.DataSetName = "schoolmanagementDataSet1";
            this.schoolmanagementDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblexpensetypeTableAdapter
            // 
            this.tblexpensetypeTableAdapter.ClearBeforeFill = true;
            // 
            // NewExpense
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(399, 254);
            this.Controls.Add(this.expensetype);
            this.Controls.Add(this.expensedate);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.amount);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.name);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.expenseid);
            this.Controls.Add(this.label3);
            this.Name = "NewExpense";
            this.Text = "NewExpense";
            this.Load += new System.EventHandler(this.NewExpense_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tblexpensetypeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolmanagementDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker expensedate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox amount;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox expenseid;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox expensetype;
        private schoolmanagementDataSet1 schoolmanagementDataSet1;
        private System.Windows.Forms.BindingSource tblexpensetypeBindingSource;
        private schoolmanagementDataSet1TableAdapters.tblexpensetypeTableAdapter tblexpensetypeTableAdapter;
    }
}