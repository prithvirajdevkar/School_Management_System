﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SchoolManagement
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void classMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Class dd = new Class();
            dd.ShowDialog();
        }

        /*private void expenseTypeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Expensetype et = new Expensetype();
            et.ShowDialog();
        }*/

        private void schoolMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SchoolDetail sd = new SchoolDetail();
            sd.ShowDialog();
        }

        private void newStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Newstudent ns = new Newstudent();
            ns.ShowDialog();
        }

        private void studentPaymetnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Studentpayment sp = new Studentpayment();
            sp.ShowDialog();
        }

        private void newAdmissionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewAdmission na = new NewAdmission();
            na.ShowDialog();
        }

        /*private void newExpenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewExpense ne = new NewExpense();
            ne.ShowDialog();
        }*/

        private void allStudentPaymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AllStudentPayment ap = new AllStudentPayment();
            ap.ShowDialog();
        }

        private void studentwisePaymentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StudentwisePayment sp = new StudentwisePayment();
            sp.ShowDialog();
        }

        private void allAdmissionDetailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AllAdmission aa = new AllAdmission();
            aa.ShowDialog();
        }

        private void studentwiseAdmissionDetailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StudentwiseAdmission sa = new StudentwiseAdmission();
            sa.ShowDialog();
        }

        private void studentDetailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Studentdetail sd = new Studentdetail();
            sd.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        /*private void expenseDetailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExpenseDetail ed = new ExpenseDetail();
            ed.ShowDialog();
        }*/
    }
}
