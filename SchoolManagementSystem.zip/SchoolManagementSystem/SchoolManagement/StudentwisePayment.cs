﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace SchoolManagement
{
    public partial class StudentwisePayment : Form
    {
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationSettings.AppSettings["School"].ToString());
        public StudentwisePayment()
        {
            InitializeComponent();
        }

        private void fullname_TextChanged(object sender, EventArgs e)
        {
            if (fullname.Text != "")
            {
                SqlDataAdapter adptr = new SqlDataAdapter("select fullname from tblstudent where fullname like '" + fullname.Text + "%'", con);
                DataSet ds = new DataSet();
                adptr.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        listBox1.Visible = true;
                        listBox1.Items.Add(dr[0]);
                    }
                }
                else
                {
                    listBox1.Items.Clear();
                    listBox1.Visible = false;
                }
            }
        }

        private void fullname_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down)
            {
                listBox1.Focus();
            }
        }

        private void listBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                fullname.Text = listBox1.SelectedItem.ToString();
                listBox1.Visible = false;
            }
        }

        private void search_Click(object sender, EventArgs e)
        {
            SqlDataAdapter adptr = new SqlDataAdapter("select * from Vw_Studenpaydetail where fullname='"+fullname.Text+"'", con);
            DataSet ds = new DataSet();
            adptr.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                dataGridView1.DataSource = ds.Tables[0];
            }
        }
    }
}
