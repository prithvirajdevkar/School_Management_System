﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace SchoolManagement
{
    public partial class Studentdetail : Form
    {
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationSettings.AppSettings["School"].ToString());
        public Studentdetail()
        {
            InitializeComponent();
        }

        private void Studentdetail_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'schoolmanagementDataSet2.tblclassmaster' table. You can move, or remove it, as needed.
            this.tblclassmasterTableAdapter.Fill(this.schoolmanagementDataSet2.tblclassmaster);

        }

        private void search_Click(object sender, EventArgs e)
        {
            if (studentid.Text == "")
            {
                SqlDataAdapter adptr = new SqlDataAdapter("select * from Vw_StudentDetail where classname='" + classname.Text + "'", con);
                DataSet ds = new DataSet();
                adptr.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dataGridView1.DataSource = ds.Tables[0];
                }
            }
            else
            {
                SqlDataAdapter adptr = new SqlDataAdapter("select * from Vw_StudentDetail where studentid="+studentid.Text+" and classname='"+classname.Text+"'", con);
                DataSet ds = new DataSet();
                adptr.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    dataGridView1.DataSource = ds.Tables[0];
                }
            }
        }
    }
}
