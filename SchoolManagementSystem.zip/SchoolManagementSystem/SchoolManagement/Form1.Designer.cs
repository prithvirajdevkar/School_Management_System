﻿namespace SchoolManagement
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.masterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.classMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.schoolMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newStudentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentPaymetnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paymentDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allStudentPaymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentwisePaymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.admissinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newAdmissionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.admissionDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allAdmissionDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentwiseAdmissionDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Verdana", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.masterToolStripMenuItem,
            this.studentToolStripMenuItem,
            this.admissinToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(993, 31);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // masterToolStripMenuItem
            // 
            this.masterToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.classMasterToolStripMenuItem,
            this.schoolMasterToolStripMenuItem});
            this.masterToolStripMenuItem.Name = "masterToolStripMenuItem";
            this.masterToolStripMenuItem.Size = new System.Drawing.Size(85, 27);
            this.masterToolStripMenuItem.Text = "Master";
            // 
            // classMasterToolStripMenuItem
            // 
            this.classMasterToolStripMenuItem.Name = "classMasterToolStripMenuItem";
            this.classMasterToolStripMenuItem.Size = new System.Drawing.Size(215, 28);
            this.classMasterToolStripMenuItem.Text = "Class Master";
            this.classMasterToolStripMenuItem.Click += new System.EventHandler(this.classMasterToolStripMenuItem_Click);
            // 
            // schoolMasterToolStripMenuItem
            // 
            this.schoolMasterToolStripMenuItem.Name = "schoolMasterToolStripMenuItem";
            this.schoolMasterToolStripMenuItem.Size = new System.Drawing.Size(215, 28);
            this.schoolMasterToolStripMenuItem.Text = "School Master";
            this.schoolMasterToolStripMenuItem.Click += new System.EventHandler(this.schoolMasterToolStripMenuItem_Click);
            // 
            // studentToolStripMenuItem
            // 
            this.studentToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newStudentToolStripMenuItem,
            this.studentPaymetnToolStripMenuItem,
            this.paymentDetailToolStripMenuItem,
            this.studentDetailToolStripMenuItem});
            this.studentToolStripMenuItem.Name = "studentToolStripMenuItem";
            this.studentToolStripMenuItem.Size = new System.Drawing.Size(96, 27);
            this.studentToolStripMenuItem.Text = "Student";
            // 
            // newStudentToolStripMenuItem
            // 
            this.newStudentToolStripMenuItem.Name = "newStudentToolStripMenuItem";
            this.newStudentToolStripMenuItem.Size = new System.Drawing.Size(230, 28);
            this.newStudentToolStripMenuItem.Text = "New Student";
            this.newStudentToolStripMenuItem.Click += new System.EventHandler(this.newStudentToolStripMenuItem_Click);
            // 
            // studentPaymetnToolStripMenuItem
            // 
            this.studentPaymetnToolStripMenuItem.Name = "studentPaymetnToolStripMenuItem";
            this.studentPaymetnToolStripMenuItem.Size = new System.Drawing.Size(230, 28);
            this.studentPaymetnToolStripMenuItem.Text = "Student Paymet";
            this.studentPaymetnToolStripMenuItem.Click += new System.EventHandler(this.studentPaymetnToolStripMenuItem_Click);
            // 
            // paymentDetailToolStripMenuItem
            // 
            this.paymentDetailToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.allStudentPaymentToolStripMenuItem,
            this.studentwisePaymentToolStripMenuItem});
            this.paymentDetailToolStripMenuItem.Name = "paymentDetailToolStripMenuItem";
            this.paymentDetailToolStripMenuItem.Size = new System.Drawing.Size(230, 28);
            this.paymentDetailToolStripMenuItem.Text = "Payment Detail";
            // 
            // allStudentPaymentToolStripMenuItem
            // 
            this.allStudentPaymentToolStripMenuItem.Name = "allStudentPaymentToolStripMenuItem";
            this.allStudentPaymentToolStripMenuItem.Size = new System.Drawing.Size(285, 28);
            this.allStudentPaymentToolStripMenuItem.Text = "All Student Payment";
            this.allStudentPaymentToolStripMenuItem.Click += new System.EventHandler(this.allStudentPaymentToolStripMenuItem_Click);
            // 
            // studentwisePaymentToolStripMenuItem
            // 
            this.studentwisePaymentToolStripMenuItem.Name = "studentwisePaymentToolStripMenuItem";
            this.studentwisePaymentToolStripMenuItem.Size = new System.Drawing.Size(285, 28);
            this.studentwisePaymentToolStripMenuItem.Text = "Studentwise Payment";
            this.studentwisePaymentToolStripMenuItem.Click += new System.EventHandler(this.studentwisePaymentToolStripMenuItem_Click);
            // 
            // studentDetailToolStripMenuItem
            // 
            this.studentDetailToolStripMenuItem.Name = "studentDetailToolStripMenuItem";
            this.studentDetailToolStripMenuItem.Size = new System.Drawing.Size(230, 28);
            this.studentDetailToolStripMenuItem.Text = "Student Detail";
            this.studentDetailToolStripMenuItem.Click += new System.EventHandler(this.studentDetailToolStripMenuItem_Click);
            // 
            // admissinToolStripMenuItem
            // 
            this.admissinToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newAdmissionToolStripMenuItem,
            this.admissionDetailToolStripMenuItem});
            this.admissinToolStripMenuItem.Name = "admissinToolStripMenuItem";
            this.admissinToolStripMenuItem.Size = new System.Drawing.Size(121, 27);
            this.admissinToolStripMenuItem.Text = "Admission";
            // 
            // newAdmissionToolStripMenuItem
            // 
            this.newAdmissionToolStripMenuItem.Name = "newAdmissionToolStripMenuItem";
            this.newAdmissionToolStripMenuItem.Size = new System.Drawing.Size(242, 28);
            this.newAdmissionToolStripMenuItem.Text = "New Admission";
            this.newAdmissionToolStripMenuItem.Click += new System.EventHandler(this.newAdmissionToolStripMenuItem_Click);
            // 
            // admissionDetailToolStripMenuItem
            // 
            this.admissionDetailToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.allAdmissionDetailToolStripMenuItem,
            this.studentwiseAdmissionDetailToolStripMenuItem});
            this.admissionDetailToolStripMenuItem.Name = "admissionDetailToolStripMenuItem";
            this.admissionDetailToolStripMenuItem.Size = new System.Drawing.Size(242, 28);
            this.admissionDetailToolStripMenuItem.Text = "Admission Detail";
            // 
            // allAdmissionDetailToolStripMenuItem
            // 
            this.allAdmissionDetailToolStripMenuItem.Name = "allAdmissionDetailToolStripMenuItem";
            this.allAdmissionDetailToolStripMenuItem.Size = new System.Drawing.Size(366, 28);
            this.allAdmissionDetailToolStripMenuItem.Text = "All Admission Detail";
            this.allAdmissionDetailToolStripMenuItem.Click += new System.EventHandler(this.allAdmissionDetailToolStripMenuItem_Click);
            // 
            // studentwiseAdmissionDetailToolStripMenuItem
            // 
            this.studentwiseAdmissionDetailToolStripMenuItem.Name = "studentwiseAdmissionDetailToolStripMenuItem";
            this.studentwiseAdmissionDetailToolStripMenuItem.Size = new System.Drawing.Size(366, 28);
            this.studentwiseAdmissionDetailToolStripMenuItem.Text = "Studentwise Admission Detail";
            this.studentwiseAdmissionDetailToolStripMenuItem.Click += new System.EventHandler(this.studentwiseAdmissionDetailToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(993, 346);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem masterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem classMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem schoolMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newStudentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentPaymetnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paymentDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem admissinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newAdmissionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem admissionDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allAdmissionDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentwiseAdmissionDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allStudentPaymentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentwisePaymentToolStripMenuItem;
    }
}

