﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace SchoolManagement
{
    public partial class Login_Form : Form
    {
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationSettings.AppSettings["School"].ToString());
        public Login_Form()
        {
            InitializeComponent();
        }
        private Boolean valid()
        {
            if (user.Text == "")
            {
                MessageBox.Show("Enter the User Name");
                return false;
            }
            if (password.Text == "")
            {
                MessageBox.Show("Enter the Password");
                return false;
            }
            return true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Login_Form_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
                if (valid())
            {
                SqlDataAdapter ad = new SqlDataAdapter("select USERID,USERNAME,CONVERT(varchar(40),DECRYPTBYPASSPHRASE('USERMASTER_PASSWORD',PASSWORD)) as Password FROM USERMASTER WHERE USERNAME='" + user.Text + "'", con);
                DataSet ds = new DataSet();
                ad.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    if (password.Text == ds.Tables[0].Rows[0]["PASSWORD"].ToString())
                    {
                        Form1 fm = new Form1();
                        fm.Show();
                        this.Hide();
                    }
                    else
                    {

                        MessageBox.Show("Invalid Password");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid User Name");
                }
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void password_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
