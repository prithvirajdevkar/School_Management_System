﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace SchoolManagement
{
    public partial class Class : Form
    {
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationSettings.AppSettings["School"].ToString());
        public Class()
        {
            InitializeComponent();
        }

        private void save_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                if (classid.Text == "")
                {
                    cmd.Parameters.AddWithValue("@classid", null);
                }
                else
                {
                    cmd.Parameters.AddWithValue("@classid", classid.Text);
                }
                cmd.Parameters.AddWithValue("@classname", Classname.Text);

                SqlParameter error = cmd.Parameters.Add("@Errormsg", SqlDbType.VarChar, 500);
                error.Direction = ParameterDirection.Output;
                SqlParameter retval = cmd.Parameters.Add("@ret", SqlDbType.Int);
                retval.Direction = ParameterDirection.ReturnValue;

                cmd.CommandText = "[sp_classmaster]";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
                con.Open();
                cmd.ExecuteNonQuery();

                int ret = (int)retval.Value;

                if (ret > 0)
                {
                    MessageBox.Show("Saved Successfully");
                    Classname.Clear();
                }
                else
                {
                    string err = (string)error.Value;
                    MessageBox.Show(err);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
