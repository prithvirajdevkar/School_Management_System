﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace SchoolManagement
{
    public partial class AllAdmission : Form
    {
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationSettings.AppSettings["School"].ToString());
        public AllAdmission()
        {
            InitializeComponent();
        }

        private void AllAdmission_Load(object sender, EventArgs e)
        {
            SqlDataAdapter adptr = new SqlDataAdapter("select * from Vw_Admissiondetail", con);
            DataSet ds = new DataSet();
            adptr.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                dataGridView1.DataSource = ds.Tables[0];
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
