﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace SchoolManagement
{
    public partial class NewExpense : Form
    {
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationSettings.AppSettings["School"].ToString());
        public NewExpense()
        {
            InitializeComponent();
        }

        private void NewExpense_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'schoolmanagementDataSet1.tblexpensetype' table. You can move, or remove it, as needed.
            this.tblexpensetypeTableAdapter.Fill(this.schoolmanagementDataSet1.tblexpensetype);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();

                cmd.Parameters.AddWithValue("@expensetypeid", expensetype.SelectedValue);
                cmd.Parameters.AddWithValue("@name", name.Text);
                cmd.Parameters.AddWithValue("@amount", amount.Text);
                cmd.Parameters.AddWithValue("@expensedate", expensedate.Value);

                SqlParameter error = cmd.Parameters.Add("@Errormsg", SqlDbType.VarChar, 500);
                error.Direction = ParameterDirection.Output;
                SqlParameter retval = cmd.Parameters.Add("@ret", SqlDbType.Int);
                retval.Direction = ParameterDirection.ReturnValue;

                cmd.CommandText = "[sp_expense]";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
                con.Open();
                cmd.ExecuteNonQuery();

                int ret = (int)retval.Value;

                if (ret > 0)
                {
                    MessageBox.Show("Saved Successfully");
                }
                else
                {
                    string err = (string)error.Value;
                    MessageBox.Show(err);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
