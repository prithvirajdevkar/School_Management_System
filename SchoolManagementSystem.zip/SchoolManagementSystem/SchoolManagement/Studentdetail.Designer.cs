﻿namespace SchoolManagement
{
    partial class Studentdetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.search = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.classname = new System.Windows.Forms.ComboBox();
            this.tblclassmasterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolmanagementDataSet2 = new SchoolManagement.schoolmanagementDataSet2();
            this.label15 = new System.Windows.Forms.Label();
            this.studentid = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tblclassmasterTableAdapter = new SchoolManagement.schoolmanagementDataSet2TableAdapters.tblclassmasterTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblclassmasterBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolmanagementDataSet2)).BeginInit();
            this.SuspendLayout();
            // 
            // search
            // 
            this.search.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.search.Location = new System.Drawing.Point(426, 31);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(75, 23);
            this.search.TabIndex = 70;
            this.search.Text = "Search";
            this.search.UseVisualStyleBackColor = true;
            this.search.Click += new System.EventHandler(this.search_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 77);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(570, 290);
            this.dataGridView1.TabIndex = 67;
            // 
            // classname
            // 
            this.classname.DataSource = this.tblclassmasterBindingSource;
            this.classname.DisplayMember = "classname";
            this.classname.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.classname.FormattingEnabled = true;
            this.classname.Location = new System.Drawing.Point(286, 31);
            this.classname.Name = "classname";
            this.classname.Size = new System.Drawing.Size(121, 24);
            this.classname.TabIndex = 78;
            this.classname.ValueMember = "classid";
            // 
            // tblclassmasterBindingSource
            // 
            this.tblclassmasterBindingSource.DataMember = "tblclassmaster";
            this.tblclassmasterBindingSource.DataSource = this.schoolmanagementDataSet2;
            // 
            // schoolmanagementDataSet2
            // 
            this.schoolmanagementDataSet2.DataSetName = "schoolmanagementDataSet2";
            this.schoolmanagementDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(197, 34);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(83, 16);
            this.label15.TabIndex = 77;
            this.label15.Text = "Class Name";
            // 
            // studentid
            // 
            this.studentid.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentid.Location = new System.Drawing.Point(121, 31);
            this.studentid.Name = "studentid";
            this.studentid.Size = new System.Drawing.Size(59, 23);
            this.studentid.TabIndex = 76;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(43, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 16);
            this.label1.TabIndex = 75;
            this.label1.Text = "Studentid";
            // 
            // tblclassmasterTableAdapter
            // 
            this.tblclassmasterTableAdapter.ClearBeforeFill = true;
            // 
            // Studentdetail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(594, 378);
            this.Controls.Add(this.classname);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.studentid);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.search);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Studentdetail";
            this.Text = "Studentdetail";
            this.Load += new System.EventHandler(this.Studentdetail_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblclassmasterBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolmanagementDataSet2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button search;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox classname;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox studentid;
        private System.Windows.Forms.Label label1;
        private schoolmanagementDataSet2 schoolmanagementDataSet2;
        private System.Windows.Forms.BindingSource tblclassmasterBindingSource;
        private schoolmanagementDataSet2TableAdapters.tblclassmasterTableAdapter tblclassmasterTableAdapter;
    }
}