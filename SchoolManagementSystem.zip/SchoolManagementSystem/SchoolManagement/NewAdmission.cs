﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace SchoolManagement
{
    public partial class NewAdmission : Form
    {
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationSettings.AppSettings["School"].ToString());
        public NewAdmission()
        {
            InitializeComponent();
        }

        private void NewAdmission_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'schoolmanagementDataSet.tblclassmaster' table. You can move, or remove it, as needed.
            //this.tblclassmasterTableAdapter.Fill(this.schoolmanagementDataSet.tblclassmaster);

        }

        private void fullname_TextChanged(object sender, EventArgs e)
        {
            if (fullname.Text != "")
            {
                SqlDataAdapter adptr = new SqlDataAdapter("select fullname from tblstudent where fullname like '" + fullname.Text + "%'", con);
                DataSet ds = new DataSet();
                adptr.Fill(ds);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        listBox1.Visible = true;
                        listBox1.Items.Add(dr[0]);
                    }
                }
                else
                {
                    listBox1.Items.Clear();
                    listBox1.Visible = false;
                }
            }
        }

        private void NewAdmission_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down)
            {
                listBox1.Focus();
            }
        }

        private void listBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                //fullname.Text = listBox1.SelectedItem.ToString();
                listBox1.Visible = false;
            }
        }

        private void search_Click(object sender, EventArgs e)
        {
            SqlDataAdapter adptr = new SqlDataAdapter("select * from tblstudent where fullname='" + fullname.Text + "'", con);
            DataSet ds = new DataSet();
            adptr.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                studentid.Text = ds.Tables[0].Rows[0]["studentid"].ToString();
                fname.Text = ds.Tables[0].Rows[0]["fname"].ToString();
                mname.Text = ds.Tables[0].Rows[0]["mname"].ToString();
                lname.Text = ds.Tables[0].Rows[0]["lname"].ToString();
                mobileno.Text = ds.Tables[0].Rows[0]["mobileno"].ToString();
                contactno.Text = ds.Tables[0].Rows[0]["contactno"].ToString();
                mothername.Text = ds.Tables[0].Rows[0]["mothername"].ToString();
                cast.Text = ds.Tables[0].Rows[0]["scast"].ToString();
                castcategory.Text = ds.Tables[0].Rows[0]["castcategory"].ToString();
                address.Text = ds.Tables[0].Rows[0]["address"].ToString();
                
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();

                if (studentid.Text == "")
                {
                    cmd.Parameters.AddWithValue("@studentid", null);
                }
                else
                {
                    cmd.Parameters.AddWithValue("@studentid", studentid.Text);
                }
                cmd.Parameters.AddWithValue("@fname", fname.Text);
                cmd.Parameters.AddWithValue("@mname", mname.Text);
                cmd.Parameters.AddWithValue("@lname", lname.Text);
                cmd.Parameters.AddWithValue("@mothername", mothername.Text);
                cmd.Parameters.AddWithValue("@scast", cast.Text);
                cmd.Parameters.AddWithValue("@castcategory", castcategory.Text);
                cmd.Parameters.AddWithValue("@mobileno", mobileno.Text);
                cmd.Parameters.AddWithValue("@contactno", contactno.Text);
                cmd.Parameters.AddWithValue("@address", address.Text);
                cmd.Parameters.AddWithValue("@classid", classname.SelectedValue);
                cmd.Parameters.AddWithValue("@totalfees", totalfees.Text);
                cmd.Parameters.AddWithValue("@paidfees", paidfees.Text);
                cmd.Parameters.AddWithValue("@admissiondate", admissiondate.Value);

                SqlParameter error = cmd.Parameters.Add("@Errormsg", SqlDbType.VarChar, 500);
                error.Direction = ParameterDirection.Output;
                SqlParameter retval = cmd.Parameters.Add("@ret", SqlDbType.Int);
                retval.Direction = ParameterDirection.ReturnValue;

                cmd.CommandText = "[Sp_Admission]";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
                con.Open();
                cmd.ExecuteNonQuery();

                int ret = (int)retval.Value;

                if (ret > 0)
                {
                    MessageBox.Show("Saved Successfully");
                }
                else
                {
                    string err = (string)error.Value;
                    MessageBox.Show(err);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void fullname_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down)
            {
                listBox1.Focus();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
