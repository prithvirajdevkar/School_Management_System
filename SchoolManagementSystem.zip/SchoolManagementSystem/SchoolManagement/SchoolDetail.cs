﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace SchoolManagement
{
    public partial class SchoolDetail : Form
    {
        SqlConnection con = new SqlConnection(System.Configuration.ConfigurationSettings.AppSettings["School"].ToString());
        public SchoolDetail()
        {
            InitializeComponent();
        }

        private void save_Click(object sender, EventArgs e)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();

                if (schoolid.Text == "")
                {
                    cmd.Parameters.AddWithValue("@schoolid", null);
                }
                else
                {
                    cmd.Parameters.AddWithValue("@schoolid", schoolid.Text);
                }
                cmd.Parameters.AddWithValue("@schoolname", schoolname.Text);
                cmd.Parameters.AddWithValue("@propwriter", prowriter.Text);
                cmd.Parameters.AddWithValue("@mobileno", mobileno.Text);
                cmd.Parameters.AddWithValue("@contactno", contactno.Text);

                SqlParameter error = cmd.Parameters.Add("@Errormsg", SqlDbType.VarChar, 500);
                error.Direction = ParameterDirection.Output;
                SqlParameter retval = cmd.Parameters.Add("@ret", SqlDbType.Int);
                retval.Direction = ParameterDirection.ReturnValue;

                cmd.CommandText = "Sp_schooldetail";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
                con.Open();
                cmd.ExecuteNonQuery();

                int ret = (int)retval.Value;

                if (ret > 0)
                {
                    MessageBox.Show("Saved Successfully");
                }
                else
                {
                    string err = (string)error.Value;
                    MessageBox.Show(err);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}
